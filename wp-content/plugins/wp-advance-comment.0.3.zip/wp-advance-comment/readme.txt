=== WP Advanced Comment ===

Contributors: ravisakya
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=UCYQAARPK3Q72
Tags: image,images,post,twitter,comments,advance,advanced,wordpress comment,advanced comment,forms,wordpress comment,post comment,avatar,free,premium,comments with avatar,admin search,backend search,admin,ajax,edit comments,captcha,comments,contact form 7 captcha,google,no captcha,nocaptcha,page, plugin,posts,recaptcha,shortcode,sidebar,spam,widget,ajax pagination,pagination,create forms,drag and drop,enable comments,disable comments,email notification,advance search,jquery validation,custom fields comments,unlimited custom fields,unlimited comment forms,shortcodes comment,custom design comments,akismet,spam protection,spam
Requires at least: 4.0
Tested up to: 4.8
Stable tag: 0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WP Advanced Comment is a powerful and easy to use comment system for wordpress with drag and drop custom fields builder.

== Description ==

WP Advanced Comment is a powerful and easy to use comment system for wordpress with drag and drop custom fields builder.

[youtube https://www.youtube.com/watch?v=yzzooz4EZzU]

= Main Features ( Free Version ) =

<blockquote>

1.  Easy to create forms with drag and drop options.<br>
2.  Use of Jquery Validation plugin for frontend validation.<br>
3.  Available custom fields ( Text, Textarea, Radio Button, Checkbox, DropDown/Select, Multiselect, Url, Email, Setion Break, HTML Codes )<br>
4.  Create unlimited custom fields.<br>
5. Options to show custom fields to admin only ( frontend ).<br><br>
</blockquote>

= PRO Version =

<blockquote>

1.  All free version feature.<br>
2.  PRO custom fields ( Date, Image Upload, Files Upload, Google Map, User Image, Captcha, Custom Taxonomies )
<br><br>
</blockquote>

<a href="https://codecanyon.net/item/wp-advanced-comment-pro-/14557575?ref=ravishakya">Click Here</a> to download the PRO Version.

= Demo =

<a href="http://wpadvancedcomment.ravishakya.com.np/wp-advanced-comment-demo/#respond">Click Here</a> to see the demo.

== Installation ==

1. Install WP Advanced Comment either via the WordPress.org plugin directory, or by uploading the files to your server.
1. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 0.3 =

* Added freemius

= 0.2 =

* PRO Version link added

= 0.1 =

* Initial Release